#!/usr/bin/env bash
# Levanta 2 pods Podman independientes: kb-db-pod y kb-app-pod
# Uso: ./start_pods.sh
set -euo pipefail
cd "$(dirname "$0")"

DB_NAME="${DB_NAME:-knowledgebase}"
DB_USER="${DB_USER:-kb_user}"
DB_PASSWORD="${DB_PASSWORD:-kb_password}"

echo "🔧 Construyendo imagen de la app..."
./build_app.sh

echo "🗄  Creando volumen persistente para la base de datos..."
podman volume create kb_db_data >/dev/null 2>&1 || true

echo "🗄  Levantando pod de base de datos (kb-db-pod)..."
podman pod exists kb-db-pod && podman pod rm -f kb-db-pod || true
podman pod create --name kb-db-pod -p 5432:5432

podman run -d \
  --pod kb-db-pod \
  --name kb_db \
  -e POSTGRES_DB="$DB_NAME" \
  -e POSTGRES_USER="$DB_USER" \
  -e POSTGRES_PASSWORD="$DB_PASSWORD" \
  -v kb_db_data:/var/lib/postgresql/data \
  -v "$(pwd)/db-init:/docker-entrypoint-initdb.d:Z" \
  docker.io/library/postgres:16-alpine

echo "⏳ Esperando a que la base de datos esté lista..."
for i in $(seq 1 30); do
  if podman exec kb_db pg_isready -U "$DB_USER" -d "$DB_NAME" >/dev/null 2>&1; then
    echo "✅ Base de datos lista"
    break
  fi
  sleep 1
done

DB_IP=$(podman inspect kb-db-pod --format '{{(index .Containers 0).IPAddress}}' 2>/dev/null || true)
if [ -z "$DB_IP" ]; then
  DB_IP=$(podman inspect kb_db --format '{{.NetworkSettings.IPAddress}}')
fi
echo "📡 IP del pod de base de datos: $DB_IP"

echo "🚀 Levantando pod de la app (kb-app-pod)..."
podman pod exists kb-app-pod && podman pod rm -f kb-app-pod || true
podman pod create --name kb-app-pod -p 8000:8000

podman run -d \
  --pod kb-app-pod \
  --name kb_app \
  -e DB_HOST="$DB_IP" \
  -e DB_PORT=5432 \
  -e DB_NAME="$DB_NAME" \
  -e DB_USER="$DB_USER" \
  -e DB_PASSWORD="$DB_PASSWORD" \
  localhost/kb-app:latest

echo ""
echo "✅ Listo. Pods activos:"
podman pod ps
echo ""
echo "🌐 Abre http://<ip-de-tu-servidor>:8000 en el navegador"
