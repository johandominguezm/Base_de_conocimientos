const API = "/api/repositories";

const el = {
  grid: document.getElementById("repoGrid"),
  empty: document.getElementById("emptyState"),
  stats: document.getElementById("statsRow"),
  search: document.getElementById("searchInput"),
  langFilter: document.getElementById("languageFilter"),
  favFilter: document.getElementById("favoriteFilter"),
  modalOverlay: document.getElementById("modalOverlay"),
  modalTitle: document.getElementById("modalTitle"),
  form: document.getElementById("repoForm"),
  btnNew: document.getElementById("btnNew"),
  btnCancel: document.getElementById("btnCancel"),
  fId: document.getElementById("repoId"),
  fName: document.getElementById("fName"),
  fUrl: document.getElementById("fUrl"),
  fDescription: document.getElementById("fDescription"),
  fLanguage: document.getElementById("fLanguage"),
  fTags: document.getElementById("fTags"),
  fNotes: document.getElementById("fNotes"),
  fFavorite: document.getElementById("fFavorite"),
};

let allRepos = [];
let debounceTimer = null;

function escapeHtml(str) {
  if (str == null) return "";
  return str.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

async function fetchJSON(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Error ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

async function loadStats() {
  const data = await fetchJSON("/api/stats");
  el.stats.innerHTML = `
    <div class="stat-card">
      <div class="stat-value">${data.total}</div>
      <div class="stat-label">Repositorios</div>
    </div>
    <div class="stat-card">
      <div class="stat-value">${data.favorites}</div>
      <div class="stat-label">Favoritos</div>
    </div>
    <div class="stat-card">
      <div class="stat-value">${data.by_language.length}</div>
      <div class="stat-label">Lenguajes</div>
    </div>
  `;

  const currentLang = el.langFilter.value;
  el.langFilter.innerHTML = '<option value="">Todos los lenguajes</option>' +
    data.by_language
      .map((l) => `<option value="${escapeHtml(l.language)}">${escapeHtml(l.language)} (${l.count})</option>`)
      .join("");
  el.langFilter.value = currentLang;
}

function buildQuery() {
  const params = new URLSearchParams();
  if (el.search.value.trim()) params.set("q", el.search.value.trim());
  if (el.langFilter.value) params.set("language", el.langFilter.value);
  if (el.favFilter.checked) params.set("favorite", "true");
  return params.toString();
}

async function loadRepos() {
  const qs = buildQuery();
  allRepos = await fetchJSON(`${API}${qs ? "?" + qs : ""}`);
  renderRepos();
}

function renderRepos() {
  if (allRepos.length === 0) {
    el.grid.innerHTML = "";
    el.empty.style.display = "block";
    return;
  }
  el.empty.style.display = "none";

  el.grid.innerHTML = allRepos.map((repo) => {
    const tags = (repo.tags || []).map((t) => `<span class="tag">${escapeHtml(t)}</span>`).join("");
    const lang = repo.language ? `<span class="tag tag-lang">${escapeHtml(repo.language)}</span>` : "";
    const notes = repo.notes
      ? `<div class="repo-notes-preview">${escapeHtml(repo.notes).slice(0, 160)}${repo.notes.length > 160 ? "…" : ""}</div>`
      : "";
    return `
      <div class="repo-card" data-id="${repo.id}">
        <div class="repo-card-head">
          <span class="repo-name">${escapeHtml(repo.name)}</span>
          <span class="repo-star ${repo.is_favorite ? "active" : ""}" data-action="favorite" data-id="${repo.id}" title="Marcar favorito">★</span>
        </div>
        <a class="repo-url" href="${escapeHtml(repo.url)}" target="_blank" rel="noopener">${escapeHtml(repo.url)}</a>
        ${repo.description ? `<div class="repo-description">${escapeHtml(repo.description)}</div>` : ""}
        <div class="repo-tags">${lang}${tags}</div>
        ${notes}
        <div class="repo-card-actions">
          <button class="btn btn-icon" data-action="edit" data-id="${repo.id}">Editar</button>
          <button class="btn btn-icon btn-danger-text" data-action="delete" data-id="${repo.id}">Eliminar</button>
        </div>
      </div>
    `;
  }).join("");
}

function openModal(repo = null) {
  el.form.reset();
  if (repo) {
    el.modalTitle.textContent = "Editar repositorio";
    el.fId.value = repo.id;
    el.fName.value = repo.name || "";
    el.fUrl.value = repo.url || "";
    el.fDescription.value = repo.description || "";
    el.fLanguage.value = repo.language || "";
    el.fTags.value = (repo.tags || []).join(", ");
    el.fNotes.value = repo.notes || "";
    el.fFavorite.checked = !!repo.is_favorite;
  } else {
    el.modalTitle.textContent = "Nuevo repositorio";
    el.fId.value = "";
  }
  el.modalOverlay.style.display = "flex";
}

function closeModal() {
  el.modalOverlay.style.display = "none";
}

async function handleSubmit(e) {
  e.preventDefault();
  const payload = {
    name: el.fName.value.trim(),
    url: el.fUrl.value.trim(),
    description: el.fDescription.value.trim() || null,
    language: el.fLanguage.value.trim() || null,
    tags: el.fTags.value.split(",").map((t) => t.trim()).filter(Boolean),
    notes: el.fNotes.value.trim() || null,
    is_favorite: el.fFavorite.checked,
  };

  const id = el.fId.value;
  try {
    if (id) {
      await fetchJSON(`${API}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetchJSON(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }
    closeModal();
    await Promise.all([loadRepos(), loadStats()]);
  } catch (err) {
    alert(`No se pudo guardar: ${err.message}`);
  }
}

async function handleGridClick(e) {
  const target = e.target.closest("[data-action]");
  if (!target) return;
  const action = target.dataset.action;
  const id = target.dataset.id;

  if (action === "edit") {
    const repo = allRepos.find((r) => String(r.id) === id);
    if (repo) openModal(repo);
  } else if (action === "delete") {
    if (!confirm("¿Eliminar este repositorio del knowledge base?")) return;
    try {
      await fetchJSON(`${API}/${id}`, { method: "DELETE" });
      await Promise.all([loadRepos(), loadStats()]);
    } catch (err) {
      alert(`No se pudo eliminar: ${err.message}`);
    }
  } else if (action === "favorite") {
    const repo = allRepos.find((r) => String(r.id) === id);
    if (!repo) return;
    try {
      await fetchJSON(`${API}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_favorite: !repo.is_favorite }),
      });
      await Promise.all([loadRepos(), loadStats()]);
    } catch (err) {
      alert(`No se pudo actualizar: ${err.message}`);
    }
  }
}

function debouncedReload() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadRepos, 250);
}

el.btnNew.addEventListener("click", () => openModal());
el.btnCancel.addEventListener("click", closeModal);
el.modalOverlay.addEventListener("click", (e) => {
  if (e.target === el.modalOverlay) closeModal();
});
el.form.addEventListener("submit", handleSubmit);
el.grid.addEventListener("click", handleGridClick);
el.search.addEventListener("input", debouncedReload);
el.langFilter.addEventListener("change", loadRepos);
el.favFilter.addEventListener("change", loadRepos);

(async function init() {
  await Promise.all([loadRepos(), loadStats()]);
})();
