from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, Request, HTTPException, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from db import get_pool, close_pool

templates = Jinja2Templates(directory="templates")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await get_pool()
    yield
    await close_pool()


app = FastAPI(title="Knowledge Base de Repositorios", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")


class RepoIn(BaseModel):
    name: str
    url: str
    description: Optional[str] = None
    language: Optional[str] = None
    tags: Optional[list[str]] = []
    notes: Optional[str] = None
    is_favorite: Optional[bool] = False


class RepoUpdate(BaseModel):
    name: Optional[str] = None
    url: Optional[str] = None
    description: Optional[str] = None
    language: Optional[str] = None
    tags: Optional[list[str]] = None
    notes: Optional[str] = None
    is_favorite: Optional[bool] = None


# ---------------- API ----------------

@app.get("/api/repositories")
async def list_repositories(
    q: Optional[str] = Query(None, description="Búsqueda por nombre/descripción/tag"),
    language: Optional[str] = None,
    favorite: Optional[bool] = None,
):
    pool = await get_pool()
    conditions = []
    args = []
    idx = 1

    if q:
        conditions.append(
            f"(name ILIKE ${idx} OR description ILIKE ${idx} OR notes ILIKE ${idx} OR ${idx} = ANY(tags))"
        )
        args.append(f"%{q}%")
        idx += 1
    if language:
        conditions.append(f"language ILIKE ${idx}")
        args.append(language)
        idx += 1
    if favorite is not None:
        conditions.append(f"is_favorite = ${idx}")
        args.append(favorite)
        idx += 1

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    query = f"""
        SELECT id, name, url, description, language, tags, notes,
               is_favorite, created_at, updated_at
        FROM repositories
        {where_clause}
        ORDER BY is_favorite DESC, updated_at DESC
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(query, *args)
    return [dict(r) for r in rows]


@app.get("/api/repositories/{repo_id}")
async def get_repository(repo_id: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM repositories WHERE id = $1", repo_id)
    if not row:
        raise HTTPException(status_code=404, detail="Repositorio no encontrado")
    return dict(row)


@app.post("/api/repositories", status_code=201)
async def create_repository(repo: RepoIn):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            INSERT INTO repositories (name, url, description, language, tags, notes, is_favorite)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, name, url, description, language, tags, notes,
                      is_favorite, created_at, updated_at
            """,
            repo.name, repo.url, repo.description, repo.language,
            repo.tags or [], repo.notes, repo.is_favorite,
        )
    return dict(row)


@app.put("/api/repositories/{repo_id}")
async def update_repository(repo_id: int, repo: RepoUpdate):
    pool = await get_pool()
    existing = await get_repository(repo_id)  # 404 if missing

    fields = repo.model_dump(exclude_unset=True)
    if not fields:
        return existing

    set_clauses = []
    args = []
    idx = 1
    for key, value in fields.items():
        set_clauses.append(f"{key} = ${idx}")
        args.append(value)
        idx += 1
    args.append(repo_id)

    query = f"""
        UPDATE repositories SET {', '.join(set_clauses)}
        WHERE id = ${idx}
        RETURNING id, name, url, description, language, tags, notes,
                  is_favorite, created_at, updated_at
    """
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(query, *args)
    return dict(row)


@app.delete("/api/repositories/{repo_id}", status_code=204)
async def delete_repository(repo_id: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        result = await conn.execute("DELETE FROM repositories WHERE id = $1", repo_id)
    if result == "DELETE 0":
        raise HTTPException(status_code=404, detail="Repositorio no encontrado")
    return None


@app.get("/api/stats")
async def stats():
    pool = await get_pool()
    async with pool.acquire() as conn:
        total = await conn.fetchval("SELECT COUNT(*) FROM repositories")
        favorites = await conn.fetchval("SELECT COUNT(*) FROM repositories WHERE is_favorite")
        languages = await conn.fetch(
            """
            SELECT COALESCE(language, 'Sin especificar') AS language, COUNT(*) AS count
            FROM repositories
            GROUP BY language
            ORDER BY count DESC
            """
        )
    return {
        "total": total,
        "favorites": favorites,
        "by_language": [dict(r) for r in languages],
    }


@app.get("/api/health")
async def health():
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.fetchval("SELECT 1")
    return {"status": "ok"}


# ---------------- UI ----------------

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
