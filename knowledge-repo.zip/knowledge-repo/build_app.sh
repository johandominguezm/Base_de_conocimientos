#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/app"
podman build -t localhost/kb-app:latest .
echo "✅ Imagen localhost/kb-app:latest construida"
