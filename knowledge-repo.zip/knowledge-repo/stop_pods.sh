#!/usr/bin/env bash
set -euo pipefail
echo "🛑 Deteniendo pods..."
podman pod stop kb-app-pod kb-db-pod 2>/dev/null || true
podman pod rm kb-app-pod kb-db-pod 2>/dev/null || true
echo "✅ Pods eliminados (el volumen kb_db_data se conserva)."
echo "   Para borrar también los datos: podman volume rm kb_db_data"
